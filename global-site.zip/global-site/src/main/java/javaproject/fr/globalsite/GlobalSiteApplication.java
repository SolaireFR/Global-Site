package javaproject.fr.globalsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalSiteApplication.class, args);
	}

}
